import pandas as pd
from django.shortcuts import render
from math import *
from string import *
import pickle
import os
import csv


def index(request):
    N = 500
    freq = {}
    current_dir = os.path.dirname(__file__)
    stopwords_file = os.path.join(current_dir, 'collection', 'stopwords.txt')
    ListCar = {'.', ',', '!', '?', '’', '-', ':', ';', '(', ')', '[', ']', '{', '}', '/', '\\', '|', '@', '#', '^', '&'}
    with open(stopwords_file, 'r') as x:
        stoplist = x.read().lower().split()

    data = pd.read_csv(os.path.join(current_dir, 'collection', 'netflix_titles.csv'))
    for k in range(1,N+1):
        #print("   *************** Indexe de fréquences du document ", k, " ***************\n")
        description = data.loc[k,'description'].lower()  # Assuming description is in the 11th column
        for char in ListCar:
            description = description.replace(char, " ")
        words = description.lower().split()
        for w in words:
            if w not in stoplist and len(w) > 1:
                freq[(w, k)] = words.count(w)

        title = data.loc[k,'title'].lower()  # Assuming description is in the 11th column
        for char in ListCar:
            title = title.replace(char, " ")
        words = title.lower().split()
        for w in words:
            if w not in stoplist and len(w) > 1:
                freq[(w, k)] = words.count(w)        

    #print("Le fichier inverse de la collection:  ")
    #print(freq)
    #print("\n")

    ni = {}
    for (w, d) in freq:
        ni[w] = ni.get(w, 0) + 1

    max_freq = {}
    for (w, d) in freq:
        max_freq[d] = max(max_freq.get(d, 0), freq[(w, d)])

    poids = {}
    for (w, d) in freq:
        poids[(w, d)] = (freq[(w, d)] / max_freq[d]) * log10((N / ni[w]) + 1)

    #print("le fichier des poids est: ")
    #print(poids)
    #print("\n")

    with open(os.path.join(current_dir, 'collection','MonIndex.pkl'), "wb") as tf:
        pickle.dump(poids, tf)

    return render(request, 'index.html')


#
#
#
#
#
#
#
#
#


def search(request):
    current_dir = os.path.dirname(__file__)
    # Load the TF-IDF weights
    with open(os.path.join(current_dir, 'collection', 'MonIndex.pkl'), "rb") as tf_file:
        poids = pickle.load(tf_file)
    # Define ListCar and stopwords
    stopwords_file = os.path.join(current_dir, 'collection', 'stopwords.txt')
    ListCar = {'.', ',', '!', '?', '’', '-'}
    with open(stopwords_file, 'r') as x:
        stoplist = x.read().lower().split()

    N = 500  # Assuming N=4
    ni = {}
    for (w, d) in poids:
        if w not in ni:
            ni[w] = 1
        else:
            ni[w] += 1

    def produit_Interne(poids, q):
        rsv = {}
        q = q.lower()
        for char in ListCar:
            q = q.replace(char, " ")
        qT = q.split()

        for i in range(N):
            rsv[i+1] = 0
        for (t, d) in poids:
            if t in qT:
                if t not in stoplist:
                    rsv[d] = rsv[d] + poids[t, d]
        return rsv

    def cosinus(poids, q):
        rsv = {}
        q = q.lower()
        for char in ListCar:
            q = q.replace(char, " ")
        qT = q.split()
        som = {}
        SQT = 0

        for i in range(N):
            som[i+1] = 0

        for t in qT:
            if t in ni:
                SQT += 1

        if SQT == 0:
            for i in range(N):
                rsv[i+1] = 0
        else:
            rsv = produit_Interne(poids, q)
            for (t, d) in poids:
                som[d] = som[d] + (poids[t, d] * poids[t, d])

            for d in rsv:
                rsv[d] = rsv[d] / sqrt(som[d] * SQT)

        return rsv

    # Handle GET request and process search query
    if request.method == 'GET' and 'search_query' in request.GET:
        search_query = request.GET.get('search_query', '')
        #print("Searched Query:", search_query)
        rsv = cosinus(poids, search_query)

        # Sort the results by relevance score
        sorted_results = sorted(rsv.items(), key=lambda item: item[1], reverse=True)
        search_results = []
        #print('Le resultat de la recherche pour cette requête est : ')
        data = pd.read_csv(os.path.join(current_dir, 'collection', 'netflix_titles.csv'))
        for doc, score in sorted_results:
            #print('Document', doc, ':', score)
            # Subtract 1 from doc since Python uses 0-based indexing
            doc_name = data.loc[doc, 'title']
            document_content = data.loc[doc, 'description']
            if score != 0:
                search_results.append({'nom_doc': doc_name, 'document_content': document_content, 'score': score})
    else:
        msg = "You need to type a query first!"
        return render(request, 'index.html', {'message': msg})
    return render(request, 'search.html', {'search_query': search_query, 'search_results': search_results})
